// Загрузка корзины из localStorage
let total = localStorage.getItem("cartTotal") 
    ? parseInt(localStorage.getItem("cartTotal")) 
    : 0;

document.getElementById("cartTotal").textContent = total;

function addToCart(price) {
    total += price;
    localStorage.setItem("cartTotal", total);
    document.getElementById("cartTotal").textContent = total;
}

// Модальное окно
function openModal() {
    document.getElementById("modal").style.display = "flex";
}

function closeModal() {
    document.getElementById("modal").style.display = "none";
}

// Валидация формы
function submitForm() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let message = document.getElementById("message");

    if (name === "" || email === "") {
        message.style.color = "red";
        message.textContent = "Пожалуйста, заполните все поля!";
    } else {
        message.style.color = "green";
        message.textContent = "Регистрация успешна!";
    }
}